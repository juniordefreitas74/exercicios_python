# processamento_de_imagens

Descrição.
O pacote de processamento de imagens é usado para:
    Processamento:
        - Correspondência de Histograma
        - Similaridade de estrutura
        - Redimensionar Imagem
    Utilidades:
        - Ler Imagem
        - Salvar imagem
        - Exibir Imagem
        - Exibir resultado
        - Exibir histrograma
## Instalação

Use o Gerenciador de Pacotes [pip](https://pip.pypa.io/en/estable/) para instalar o 'nome do pacote'

---
    bash
pip install processamento_de_imagens

## Autor
Junior de Freitas

## Licensa

